/**
 * 
 */
/**
 * @author Hp
 *
 */
module A18Rgit {
	requires java.sql;
}