package com.tns.dayeight.interfaces;

public interface Registrable {

}
