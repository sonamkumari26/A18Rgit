package com.tns.daysix.staticblockmethod;

public class MyclassDemo {

	public static void main(String[] args) {


		MyClass my = new MyClass();
		System.out.println(my);
		
		MyClass.display();

	}

}
