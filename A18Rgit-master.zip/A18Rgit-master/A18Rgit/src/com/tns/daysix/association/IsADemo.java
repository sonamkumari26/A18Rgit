package com.tns.daysix.association;

public class IsADemo {

	public static void main(String[] args) {
 
		Manager mgr = new Manager("sai",101,"cse",100);
		
		System.out.println(mgr);

	}

}
