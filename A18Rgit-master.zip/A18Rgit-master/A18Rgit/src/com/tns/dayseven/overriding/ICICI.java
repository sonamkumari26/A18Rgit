package com.tns.dayseven.overriding;
//subclass
public class ICICI extends RBI {
	@Override
	public float getRateOfInterest() {
		return 6.9f;
	}

}