package com.tns.daynine.exception;

public class NestedTrydemo {

	public static void main(String[] args) {
		
		Nestedtrycatch.check();
	}

}
