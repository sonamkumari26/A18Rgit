package com.tns.daynine.exception;

public class Finallyblockdemo {

	public static void main(String[] args) {


		FinallyBlockex.divide(100,0);
	}

}
