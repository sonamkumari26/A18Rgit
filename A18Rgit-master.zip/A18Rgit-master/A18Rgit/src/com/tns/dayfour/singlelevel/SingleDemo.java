package com.tns.dayfour.singlelevel;

public class SingleDemo {

	public static void main(String[] args) {
		
		Student st = new Student();
		
		st.setName("Punith");
		st.setAadharNo("118998");
		st.setAddress("bangalore");
		st.setPhno(900840013);
		st.setRollNo(101);
         st.setCollegeName("RGIT");
         
         System.out.println(st);
	}

}
