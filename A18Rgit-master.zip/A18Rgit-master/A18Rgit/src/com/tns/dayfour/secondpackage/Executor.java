package com.tns.dayfour.secondpackage;

import com.tns.dayfour.firstpackage.Base;

public class Executor {

	public static void main(String[] args) {


		Base b1 = new Base();
		
		b1.methodPublic();
		
	

	}

}
