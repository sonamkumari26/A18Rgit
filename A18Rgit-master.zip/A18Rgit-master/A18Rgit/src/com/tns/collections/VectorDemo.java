package com.tns.collections;

import java.util.ArrayList;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {


		/* Vector <Integer> value = new Vector<>(); */
		
		ArrayList <Integer >value = new ArrayList<>();
		
		value.add(100);
		value.add(200);
		value.add(300);
		value.add(400);
		value.add(500);
		value.add(600);
		value.add(700);
		value.add(800);
		value.add(900);
		value.add(1100);
		value.add(500);
		value.add(600);
		value.add(700);
		value.add(800);
		value.add(900);
		value.add(1100);
		
		
		System.out.println(value.size());
		
	}

}
