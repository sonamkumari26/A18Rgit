package com.tns.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {


	 Map <String,String> value = new TreeMap<>();
	 
	 value.put("srikanth","9008400136");
	 value.put("sai", "98989898");
	 value.put("saikiran", "988799898");
	 value.put("kumar", "9898989798");
	 
	 System.out.println(value);

	}

}
