package com.tnsif.dayone;

public class FirstProgram {

	public static void main(String[] args) {

    System.out.println("Hello RGIT!");
    System.out.print("Hello TNSIF !");

	}

}
