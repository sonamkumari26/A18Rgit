package com.tnsif.dayone;

public class BreakDemo {
	public static void main(String[] args) {

		for (int i = 5; i < 10; i++) {
			if (i == 5)
				
			System.out.println(i);
			break;
		}

	}
}